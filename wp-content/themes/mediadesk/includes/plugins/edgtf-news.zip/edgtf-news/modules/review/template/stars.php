<div class="edgtf-news-review-stars-holder">
	<div class="edgtf-news-review-stars-all">
		<?php for ( $i = 1; $i <= 5; $i ++ ) { ?>
			<span class="edgtf-nr-star fa fa-star"></span>
		<?php } ?>
	</div>
	<div class="edgtf-news-review-stars" <?php mediadesk_edge_inline_style( $style ) ?>>
		<?php for ( $i = 1; $i <= 5; $i ++ ) { ?>
			<span class="edgtf-nr-star fa fa-star"></span>
		<?php } ?>
	</div>
</div>