<?php

include_once EDGE_NEWS_WIDGETS_PATH . '/latest-news/functions.php';
include_once EDGE_NEWS_WIDGETS_PATH . '/latest-news/latest-news.php';