<div class="edgtf-news-item edgtf-layout9-item edgtf-item-space">
	<div class="edgtf-ni-content">
		<div class="edgtf-ni-info edgtf-ni-info-top">
			<?php echo edgtf_news_get_shortcode_inner_template_part( 'post-info/category', '', $params ); ?>
			<?php echo edgtf_news_get_shortcode_inner_template_part( 'post-info/date', '', $params ); ?>
		</div>
		<?php echo edgtf_news_get_shortcode_inner_template_part( 'title', '', $params ); ?>
		<?php echo edgtf_news_get_shortcode_inner_template_part( 'excerpt', '', $params ); ?>
	</div>
</div>