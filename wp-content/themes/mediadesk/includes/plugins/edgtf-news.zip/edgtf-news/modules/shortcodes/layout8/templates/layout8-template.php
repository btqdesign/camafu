<div class="edgtf-news-item edgtf-layout8-item edgtf-item-space">
	<div class="edgtf-ni-item-inner">
		<div class="edgtf-ni-image-holder">
			<?php echo edgtf_news_get_shortcode_inner_template_part( 'image', '', $params ); ?>
		</div>
		<div class="edgtf-ni-content">
			<?php echo edgtf_news_get_shortcode_inner_template_part( 'title', '', $params ); ?>
		</div>
	</div>
</div>