<?php

include_once EDGE_NEWS_SHORTCODES_PATH . '/post-carousel3/functions.php';
include_once EDGE_NEWS_SHORTCODES_PATH . '/post-carousel3/post-carousel3.php';