<?php

include_once EDGE_NEWS_SHORTCODES_PATH . '/layout6/functions.php';
include_once EDGE_NEWS_SHORTCODES_PATH . '/layout6/layout6.php';