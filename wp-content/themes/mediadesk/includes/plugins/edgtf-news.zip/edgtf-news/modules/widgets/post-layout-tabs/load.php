<?php

include_once EDGE_NEWS_WIDGETS_PATH . '/post-layout-tabs/functions.php';
include_once EDGE_NEWS_WIDGETS_PATH . '/post-layout-tabs/post-layout-tabs.php';
