<?php

include_once EDGE_NEWS_SHORTCODES_PATH . '/layout10/functions.php';
include_once EDGE_NEWS_SHORTCODES_PATH . '/layout10/layout10.php';