<?php

include_once EDGE_NEWS_SHORTCODES_PATH . '/layout9/functions.php';
include_once EDGE_NEWS_SHORTCODES_PATH . '/layout9/layout9.php';