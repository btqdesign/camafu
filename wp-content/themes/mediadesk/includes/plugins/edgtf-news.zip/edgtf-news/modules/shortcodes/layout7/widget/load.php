<?php

include_once EDGE_NEWS_SHORTCODES_PATH . '/layout7/widget/functions.php';
include_once EDGE_NEWS_SHORTCODES_PATH . '/layout7/widget/layout7.php';