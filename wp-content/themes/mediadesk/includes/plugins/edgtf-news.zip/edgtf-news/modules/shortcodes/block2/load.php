<?php

include_once EDGE_NEWS_SHORTCODES_PATH . '/block2/functions.php';
include_once EDGE_NEWS_SHORTCODES_PATH . '/block2/block2.php';