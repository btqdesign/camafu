<?php

include_once EDGE_NEWS_SHORTCODES_PATH . '/post-carousel4/functions.php';
include_once EDGE_NEWS_SHORTCODES_PATH . '/post-carousel4/post-carousel4.php';