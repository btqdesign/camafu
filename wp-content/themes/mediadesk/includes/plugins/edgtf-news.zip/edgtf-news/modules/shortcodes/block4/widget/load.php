<?php

include_once EDGE_NEWS_SHORTCODES_PATH . '/block4/widget/functions.php';
include_once EDGE_NEWS_SHORTCODES_PATH . '/block4/widget/block4.php';