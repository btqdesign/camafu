<?php

include_once EDGE_NEWS_SHORTCODES_PATH . '/layout7/functions.php';
include_once EDGE_NEWS_SHORTCODES_PATH . '/layout7/layout7.php';