<div class="edgtf-blog-like">
	<?php if ( function_exists( 'mediadesk_edge_get_like' ) ) {
		mediadesk_edge_get_like();
	} ?>
</div>