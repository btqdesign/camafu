<?php

include_once EDGE_NEWS_WIDGETS_PATH . '/weather/functions.php';
include_once EDGE_NEWS_WIDGETS_PATH . '/weather/weather.php';