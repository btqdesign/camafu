<div class="edgtf-news-item edgtf-layout6-item edgtf-item-space">
	<div class="edgtf-ni-item-inner">
		<div class="edgtf-ni-image-holder">
			<?php echo edgtf_news_get_shortcode_inner_template_part( 'image', '', $params ); ?>
		</div>
		<div class="edgtf-ni-content">
			<?php echo edgtf_news_get_shortcode_inner_template_part( 'title', '', $params ); ?>
			<div class="edgtf-ni-info edgtf-ni-info-bottom">
				<?php echo edgtf_news_get_shortcode_inner_template_part( 'post-info/date', '', $params ); ?>
			</div>
		</div>
	</div>
</div>