<?php

include_once EDGE_NEWS_SHORTCODES_PATH . '/block1/functions.php';
include_once EDGE_NEWS_SHORTCODES_PATH . '/block1/block1.php';