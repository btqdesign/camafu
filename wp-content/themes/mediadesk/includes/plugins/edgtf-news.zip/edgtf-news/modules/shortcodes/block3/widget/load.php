<?php

include_once EDGE_NEWS_SHORTCODES_PATH . '/block3/widget/functions.php';
include_once EDGE_NEWS_SHORTCODES_PATH . '/block3/widget/block3.php';