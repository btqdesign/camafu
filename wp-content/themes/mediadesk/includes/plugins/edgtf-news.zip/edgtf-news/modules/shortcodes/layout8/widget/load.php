<?php

include_once EDGE_NEWS_SHORTCODES_PATH . '/layout8/widget/functions.php';
include_once EDGE_NEWS_SHORTCODES_PATH . '/layout8/widget/layout8.php';