<?php

include_once EDGE_NEWS_SHORTCODES_PATH . '/layout8/functions.php';
include_once EDGE_NEWS_SHORTCODES_PATH . '/layout8/layout8.php';