<?php

include_once EDGE_NEWS_SHORTCODES_PATH . '/layout10/widget/functions.php';
include_once EDGE_NEWS_SHORTCODES_PATH . '/layout10/widget/layout10.php';