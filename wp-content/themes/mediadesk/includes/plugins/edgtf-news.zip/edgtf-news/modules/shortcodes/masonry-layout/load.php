<?php

include_once EDGE_NEWS_SHORTCODES_PATH . '/masonry-layout/functions.php';
include_once EDGE_NEWS_SHORTCODES_PATH . '/masonry-layout/masonry-layout.php';